import requests
import re
import sys
import time
from pathlib import Path


def check_username(username: str) -> dict:
    """
    Check if a Minecraft username is available using the Mojang API.
    Returns a dict with status and details.
    """
    if not (3 <= len(username) <= 16):
        return {
            "username": username,
            "status": "invalid",
            "message": f"'{username}' is INVALID — must be 3–16 characters long."
        }

    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return {
            "username": username,
            "status": "invalid",
            "message": f"'{username}' is INVALID — only letters, numbers, and underscores allowed."
        }

    url = f"https://api.mojang.com/users/profiles/minecraft/{username}"
    try:
        response = requests.get(url, timeout=5)
    except requests.exceptions.RequestException as e:
        return {
            "username": username,
            "status": "error",
            "message": f"Network error: {e}"
        }

    if response.status_code == 200:
        data = response.json()
        return {
            "username": username,
            "status": "taken",
            "uuid": data.get("id"),
            "exact_name": data.get("name"),
            "message": f"'{username}' is TAKEN"
        }
    elif response.status_code == 404:
        return {
            "username": username,
            "status": "available",
            "message": f"'{username}' is AVAILABLE!"
        }
    elif response.status_code == 429:
        return {
            "username": username,
            "status": "rate_limited",
            "message": f"'{username}' — rate limited, skipped."
        }
    else:
        return {
            "username": username,
            "status": "error",
            "message": f"'{username}' — unexpected API response: {response.status_code}"
        }


def print_result(result: dict):
    icons = {
        "available":    "",
        "taken":        "",
        "invalid":      " ",
        "error":        "",
        "rate_limited": "",
    }
    icon = icons.get(result["status"], "")
    print(f"{icon}  {result['message']}")
    if result["status"] == "taken":
        print(f"      Exact name : {result['exact_name']}")
        print(f"      UUID       : {result['uuid']}")


def load_from_file(filepath: str) -> list:
    """Read usernames from a .txt file, one per line."""
    path = Path(filepath)
    if not path.exists():
        print(f"  File not found: {filepath}")
        sys.exit(1)
    if path.suffix.lower() != ".txt":
        print(f"   Expected a .txt file, got: {path.suffix}")
        sys.exit(1)

    usernames = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            name = line.strip()
            if name and not name.startswith("#"):  # skip blank lines & comments
                usernames.append(name)
    return usernames


def save_results(results: list, out_path: str):
    """Save results summary to a txt file."""
    with open(out_path, "w", encoding="utf-8") as f:
        available = [r for r in results if r["status"] == "available"]
        taken     = [r for r in results if r["status"] == "taken"]
        other     = [r for r in results if r["status"] not in ("available", "taken")]

        f.write("MINECRAFT USERNAME CHECK RESULTS\n")
        f.write("=" * 40 + "\n\n")

        f.write(f"AVAILABLE ({len(available)})\n")
        f.write("-" * 40 + "\n")
        for r in available:
            f.write(f"  {r['username']}\n")

        f.write(f"\nTAKEN ({len(taken)})\n")
        f.write("-" * 40 + "\n")
        for r in taken:
            f.write(f"  {r['username']} | UUID: {r['uuid']}\n")

        if other:
            f.write(f"\nOTHER ({len(other)})\n")
            f.write("-" * 40 + "\n")
            for r in other:
                f.write(f"  {r['message']}\n")

    print(f"\n  Results saved to: {out_path}")


def main():
    print("=" * 50)
    print("   Minecraft Username Checker")
    print("=" * 50)

    usernames = []

    # Determine input source
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg.endswith(".txt"):
            print(f"\n  Loading usernames from: {arg}")
            usernames = load_from_file(arg)
            print(f"    Found {len(usernames)} username(s).\n")
        else:
            usernames = sys.argv[1:]
    else:
        print("\nOptions:")
        print("  [1] Enter usernames manually")
        print("  [2] Load from a .txt file")
        choice = input("\nChoose (1/2): ").strip()

        if choice == "2":
            filepath = input("Path to .txt file: ").strip()
            usernames = load_from_file(filepath)
            print(f"    Found {len(usernames)} username(s).\n")
        else:
            raw = input("Enter username(s) (comma-separated): ")
            usernames = [u.strip() for u in raw.split(",") if u.strip()]

    if not usernames:
        print("No usernames provided. Exiting.")
        return

    # Check all usernames
    results = []
    total = len(usernames)
    for i, username in enumerate(usernames, 1):
        print(f"[{i}/{total}] Checking: {username}...")
        result = check_username(username)
        print_result(result)
        results.append(result)
        if i < total:
            time.sleep(0.6)  # respect Mojang rate limits

    # Summary
    available_count = sum(1 for r in results if r["status"] == "available")
    taken_count     = sum(1 for r in results if r["status"] == "taken")
    print("\n" + "=" * 50)
    print(f"  Done! {total} checked — {available_count} available, {taken_count} taken.")
    print("=" * 50)

    # Optionally save results
    save = input("\nSave results to a file? (y/n): ").strip().lower()
    if save == "y":
        out = input("Output filename (e.g. results.txt): ").strip() or "results.txt"
        save_results(results, out)


if __name__ == "__main__":
    main()
